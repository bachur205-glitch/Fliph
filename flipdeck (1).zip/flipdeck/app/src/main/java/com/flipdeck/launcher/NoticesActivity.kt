package com.flipdeck.launcher

import android.app.Activity
import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Notification list. D-pad up/down to move, OK opens the notice and clears it. */
class NoticesActivity : BaseActivity() {

    private class Row(
        val kind: Int,
        val sbn: StatusBarNotification?,
        val text: String,
        val music: NowPlaying.Info? = null
    )

    private companion object {
        const val NOTE = 0
        const val CLEAR = 1
        const val GRANT = 2
        const val EMPTY = 3
        const val MUSIC = 4
    }

    private var rows: List<Row> = emptyList()
    private lateinit var list: ListView
    private val handler = Handler(Looper.getMainLooper())
    private var lastMusic = ""

    // Keeps the music widget current (track changes, play/pause from elsewhere).
    private val musicTicker = object : Runnable {
        override fun run() {
            val now = if (NoticeStore.isEnabled(this@NoticesActivity)) {
                NowPlaying.current(this@NoticesActivity)?.signature ?: ""
            } else ""
            if (now != lastMusic) refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private fun tv(text: CharSequence, size: Float, color: Int, bold: Boolean = false, lines: Int = 1) =
        TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setTextColor(color)
            maxLines = lines
            ellipsize = TextUtils.TruncateAt.END
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

    private val rowAdapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val ctx = this@NoticesActivity
            val r = rows[position]
            val v = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
            }
            if (r.kind == MUSIC && r.music != null) {
                val m = r.music
                v.setBackgroundColor(Color.parseColor("#14324A"))
                v.addView(tv(if (m.playing) "NOW PLAYING" else "PAUSED", 12f, Ui.ACCENT, true))
                v.addView(tv(m.title, 16f, Ui.TEXT, true))
                if (m.artist.isNotEmpty()) v.addView(tv(m.artist, 14f, Ui.SUB))
                v.addView(
                    tv(
                        if (m.playing) "OK: pause    < prev   next >" else "OK: play    < prev   next >",
                        12f,
                        Ui.ON
                    ).apply { setPadding(0, dp(4), 0, 0) }
                )
            } else if (r.kind == NOTE && r.sbn != null) {
                val n = r.sbn
                val extras = n.notification.extras
                v.addView(tv(appName(n.packageName), 12f, Ui.ACCENT))
                v.addView(
                    tv(extras.getCharSequence(Notification.EXTRA_TITLE) ?: "", 16f, Ui.TEXT, true)
                )
                v.addView(
                    tv(extras.getCharSequence(Notification.EXTRA_TEXT) ?: "", 14f, Ui.SUB, false, 2)
                )
            } else {
                v.addView(
                    tv(r.text, 18f, Ui.TEXT, true).apply { gravity = Gravity.CENTER }
                )
            }
            return v
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        list = ListView(this).apply {
            divider = null
            selector = Ui.selector(this@NoticesActivity)
            adapter = rowAdapter
            setOnItemClickListener { _, _, position, _ -> onRowChosen(rows[position]) }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        root.addView(Ui.header(this, "Notices"))
        root.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        NoticeStore.listener = { runOnUiThread { refresh() } }
        refresh()
        list.requestFocus()
        handler.postDelayed(musicTicker, 1000)
    }

    override fun onPause() {
        handler.removeCallbacks(musicTicker)
        NoticeStore.listener = null
        super.onPause()
    }

    private fun selectedRow(): Row? = rows.getOrNull(list.selectedItemPosition)

    /** On the music widget, left / right skip tracks. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val music = selectedRow()?.takeIf { it.kind == MUSIC }?.music
        if (music != null && event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    music.previous()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    music.next()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun refresh() {
        val r = mutableListOf<Row>()
        lastMusic = ""
        if (!NoticeStore.isEnabled(this)) {
            r.add(Row(GRANT, null, "Press OK to allow notice access"))
        } else {
            NowPlaying.current(this)?.let {
                lastMusic = it.signature
                r.add(Row(MUSIC, null, "", it))
            }
            val active = NoticeStore.active()
            if (active.isEmpty()) {
                r.add(Row(EMPTY, null, "No notices"))
            } else {
                active.forEach { r.add(Row(NOTE, it, "")) }
                r.add(Row(CLEAR, null, "Clear all"))
            }
        }
        rows = r
        rowAdapter.notifyDataSetChanged()
    }

    private fun onRowChosen(r: Row) {
        when (r.kind) {
            MUSIC -> {
                r.music?.playPause()
                // Give the player a moment, then redraw so the widget shows the new state.
                handler.postDelayed({ refresh() }, 400)
            }
            GRANT -> try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                Actions.toast(this, "Can't open that")
            }
            CLEAR -> {
                try {
                    NoticeStore.service?.cancelAllNotifications()
                } catch (e: Exception) {
                    // ignore
                }
                refresh()
            }
            NOTE -> r.sbn?.let { n ->
                try {
                    n.notification.contentIntent?.send()
                } catch (e: PendingIntent.CanceledException) {
                    Actions.toast(this, "Can't open that")
                }
                try {
                    NoticeStore.service?.cancelNotification(n.key)
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
    }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}
