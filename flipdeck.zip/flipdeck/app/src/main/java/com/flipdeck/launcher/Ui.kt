package com.flipdeck.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

object Ui {
    val BG: Int = Color.parseColor("#0B0F14")
    val PANEL: Int = Color.parseColor("#1A222C")
    val TEXT: Int = Color.WHITE
    val SUB: Int = Color.parseColor("#9FB3C8")
    val ACCENT: Int = Color.parseColor("#4FC3F7")
    val ON: Int = Color.parseColor("#66E08A")

    /** Highlight drawn behind the currently selected D-pad item. */
    fun selector(ctx: Context): Drawable = GradientDrawable().apply {
        setColor(Color.parseColor("#223244"))
        cornerRadius = ctx.dp(12).toFloat()
        setStroke(ctx.dp(2), ACCENT)
    }

    fun header(ctx: Context, title: String): TextView = TextView(ctx).apply {
        text = title
        setTextColor(TEXT)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setBackgroundColor(PANEL)
        setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
    }
}
