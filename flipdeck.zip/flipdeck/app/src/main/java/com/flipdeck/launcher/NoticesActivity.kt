package com.flipdeck.launcher

import android.app.Activity
import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Notification list. D-pad up/down to move, OK opens the notice and clears it. */
class NoticesActivity : Activity() {

    private class Row(val kind: Int, val sbn: StatusBarNotification?, val text: String)

    private companion object {
        const val NOTE = 0
        const val CLEAR = 1
        const val GRANT = 2
        const val EMPTY = 3
    }

    private var rows: List<Row> = emptyList()
    private lateinit var list: ListView

    private fun tv(text: CharSequence, size: Float, color: Int, bold: Boolean = false, lines: Int = 1) =
        TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setTextColor(color)
            maxLines = lines
            ellipsize = TextUtils.TruncateAt.END
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

    private val rowAdapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val ctx = this@NoticesActivity
            val r = rows[position]
            val v = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
            }
            if (r.kind == NOTE && r.sbn != null) {
                val n = r.sbn
                val extras = n.notification.extras
                v.addView(tv(appName(n.packageName), 12f, Ui.ACCENT))
                v.addView(
                    tv(extras.getCharSequence(Notification.EXTRA_TITLE) ?: "", 16f, Ui.TEXT, true)
                )
                v.addView(
                    tv(extras.getCharSequence(Notification.EXTRA_TEXT) ?: "", 14f, Ui.SUB, false, 2)
                )
            } else {
                v.addView(
                    tv(r.text, 18f, Ui.TEXT, true).apply { gravity = Gravity.CENTER }
                )
            }
            return v
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        list = ListView(this).apply {
            divider = null
            selector = Ui.selector(this@NoticesActivity)
            adapter = rowAdapter
            setOnItemClickListener { _, _, position, _ -> onRowChosen(rows[position]) }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        root.addView(Ui.header(this, "Notices"))
        root.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        NoticeStore.listener = { runOnUiThread { refresh() } }
        refresh()
        list.requestFocus()
    }

    override fun onPause() {
        NoticeStore.listener = null
        super.onPause()
    }

    private fun refresh() {
        val r = mutableListOf<Row>()
        if (!NoticeStore.isEnabled(this)) {
            r.add(Row(GRANT, null, "Press OK to allow notice access"))
        } else {
            val active = NoticeStore.active()
            if (active.isEmpty()) {
                r.add(Row(EMPTY, null, "No notices"))
            } else {
                active.forEach { r.add(Row(NOTE, it, "")) }
                r.add(Row(CLEAR, null, "Clear all"))
            }
        }
        rows = r
        rowAdapter.notifyDataSetChanged()
    }

    private fun onRowChosen(r: Row) {
        when (r.kind) {
            GRANT -> try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                Actions.toast(this, "Can't open that")
            }
            CLEAR -> {
                try {
                    NoticeStore.service?.cancelAllNotifications()
                } catch (e: Exception) {
                    // ignore
                }
                refresh()
            }
            NOTE -> r.sbn?.let { n ->
                try {
                    n.notification.contentIntent?.send()
                } catch (e: PendingIntent.CanceledException) {
                    Actions.toast(this, "Can't open that")
                }
                try {
                    NoticeStore.service?.cancelNotification(n.key)
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
    }

    private fun appName(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}
