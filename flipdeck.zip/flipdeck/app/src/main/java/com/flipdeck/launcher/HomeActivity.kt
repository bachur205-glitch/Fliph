package com.flipdeck.launcher

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

/**
 * Home screen.
 *   OK            -> app menu (hold OK for launcher settings)
 *   D-pad up      -> quick settings
 *   D-pad others  -> whatever you bound them to
 *   Left softkey  -> notices
 *   Right softkey -> contacts
 */
class HomeActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var leftLabel: TextView
    private lateinit var downLabel: TextView
    private lateinit var rightLabel: TextView
    private lateinit var noticesLabel: TextView
    private lateinit var hebrewLabel: TextView

    // Refreshes the Hebrew date at midnight and when the clock/timezone changes.
    private val dateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = refreshLabels()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refreshLabels()
        NoticeStore.listener = { runOnUiThread { refreshLabels() } }
        registerReceiver(dateReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        })
    }

    override fun onPause() {
        NoticeStore.listener = null
        try {
            unregisterReceiver(dateReceiver)
        } catch (e: IllegalArgumentException) {
            // not registered
        }
        super.onPause()
    }

    private fun label(size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setTextColor(color)
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)

        // Clock + date in the middle.
        val center = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val clock = TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 56f)
            setTextColor(Ui.TEXT)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        val date = TextClock(this).apply {
            format12Hour = "EEE, MMM d"
            format24Hour = "EEE, MMM d"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTextColor(Ui.SUB)
            gravity = Gravity.CENTER
        }
        hebrewLabel = label(16f, Ui.ACCENT).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        }
        center.addView(clock)
        center.addView(date)
        center.addView(hebrewLabel)
        root.addView(center, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT, Gravity.CENTER))

        // Top: D-pad up hint.
        val up = label(14f, Ui.ACCENT).apply {
            text = "Quick settings"
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        root.addView(up, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.TOP))

        // Bottom: left / down / right hints, then the softkey bar.
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val dpad = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), 0, dp(8), dp(8))
        }
        leftLabel = label(13f, Ui.SUB).apply { gravity = Gravity.START }
        downLabel = label(13f, Ui.SUB).apply { gravity = Gravity.CENTER }
        rightLabel = label(13f, Ui.SUB).apply { gravity = Gravity.END }
        for (v in listOf(leftLabel, downLabel, rightLabel)) {
            v.maxLines = 1
            v.ellipsize = TextUtils.TruncateAt.END
            dpad.addView(v, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        bottom.addView(dpad)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Ui.PANEL)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        noticesLabel = label(16f, Ui.TEXT, true).apply { gravity = Gravity.START }
        val menu = label(16f, Ui.ACCENT, true).apply {
            text = "MENU"
            gravity = Gravity.CENTER
        }
        val contacts = label(16f, Ui.TEXT, true).apply {
            text = "Contacts"
            gravity = Gravity.END
        }
        for (v in listOf(noticesLabel, menu, contacts)) {
            bar.addView(v, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        bottom.addView(bar)

        root.addView(bottom, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        return root
    }

    private fun refreshLabels() {
        hebrewLabel.text = HebrewDate.today(prefs.hebrewScript)
        leftLabel.text = Actions.label(this, prefs.getBinding(Prefs.LEFT))
        downLabel.text = Actions.label(this, prefs.getBinding(Prefs.DOWN))
        rightLabel.text = Actions.label(this, prefs.getBinding(Prefs.RIGHT))
        val n = NoticeStore.active().size
        noticesLabel.text = if (n > 0) "Notices ($n)" else "Notices"
    }

    // --- Keys -------------------------------------------------------------

    private fun slotFor(code: Int): String? = when (code) {
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> "menu"
        KeyEvent.KEYCODE_DPAD_UP -> "up"
        KeyEvent.KEYCODE_DPAD_DOWN -> Prefs.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Prefs.LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> Prefs.RIGHT
        prefs.softLeftKey -> "softleft"
        prefs.softRightKey -> "softright"
        else -> null
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (slotFor(keyCode) != null || keyCode == KeyEvent.KEYCODE_BACK) {
            event.startTracking()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent): Boolean {
        if (slotFor(keyCode) == "menu") {
            startActivity(Intent(this, LauncherSettingsActivity::class.java))
            return true
        }
        return super.onKeyLongPress(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        // Back does nothing on the home screen.
        if (keyCode == KeyEvent.KEYCODE_BACK) return true
        val slot = slotFor(keyCode) ?: return super.onKeyUp(keyCode, event)
        if (event.isCanceled) return true // a long press already handled it
        when (slot) {
            "menu" -> Actions.run(this, Actions.MENU)
            "up" -> Actions.run(this, Actions.QUICK)
            "softleft" -> Actions.run(this, Actions.NOTICES)
            "softright" -> Actions.run(this, Actions.CONTACTS)
            else -> Actions.run(this, prefs.getBinding(slot))
        }
        return true
    }
}
