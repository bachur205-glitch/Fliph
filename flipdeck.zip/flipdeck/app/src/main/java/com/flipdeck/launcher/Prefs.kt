package com.flipdeck.launcher

import android.content.Context
import android.content.SharedPreferences
import android.view.KeyEvent

class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.getSharedPreferences("flipdeck", Context.MODE_PRIVATE)

    /** Action bound to a customizable D-pad direction (DOWN, LEFT or RIGHT). */
    fun getBinding(slot: String): String =
        sp.getString("bind_$slot", null) ?: DEFAULTS[slot] ?: Actions.NONE

    fun setBinding(slot: String, action: String) {
        sp.edit().putString("bind_$slot", action).apply()
    }

    var softLeftKey: Int
        get() = sp.getInt("soft_left", KeyEvent.KEYCODE_SOFT_LEFT)
        set(value) { sp.edit().putInt("soft_left", value).apply() }

    var softRightKey: Int
        get() = sp.getInt("soft_right", KeyEvent.KEYCODE_SOFT_RIGHT)
        set(value) { sp.edit().putInt("soft_right", value).apply() }

    /** true = Hebrew letters, false = English spelling (e.g. "Cheshvan"). */
    var hebrewScript: Boolean
        get() = sp.getBoolean("hebrew_script", true)
        set(value) { sp.edit().putBoolean("hebrew_script", value).apply() }

    /** 3 = large icons, 2 = huge icons. */
    var gridColumns: Int
        get() = sp.getInt("columns", 3)
        set(value) { sp.edit().putInt("columns", value).apply() }

    companion object {
        const val DOWN = "down"
        const val LEFT = "left"
        const val RIGHT = "right"

        private val DEFAULTS = mapOf(
            DOWN to Actions.DIALER,
            LEFT to Actions.MESSAGES,
            RIGHT to Actions.CAMERA
        )
    }
}
