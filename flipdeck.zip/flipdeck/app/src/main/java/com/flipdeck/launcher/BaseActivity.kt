package com.flipdeck.launcher

import android.app.Activity
import android.content.Context
import android.content.res.Configuration

/**
 * Base for every Flipdeck screen. Applies the chosen screen density (default 120 dpi) to the
 * launcher's own screens only. Other apps and the rest of the system are not affected.
 */
open class BaseActivity : Activity() {

    private var appliedDensity = 0

    override fun attachBaseContext(newBase: Context) {
        appliedDensity = Prefs(newBase).density
        if (appliedDensity > 0) {
            val config = Configuration(newBase.resources.configuration)
            config.densityDpi = appliedDensity
            super.attachBaseContext(newBase.createConfigurationContext(config))
        } else {
            super.attachBaseContext(newBase)
        }
    }

    override fun onResume() {
        super.onResume()
        // The density was changed in settings while this screen was in the background.
        if (appliedDensity != Prefs(this).density) recreate()
    }
}
