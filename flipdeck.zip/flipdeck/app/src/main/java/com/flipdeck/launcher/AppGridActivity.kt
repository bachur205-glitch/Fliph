package com.flipdeck.launcher

import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Big-icon grid of your launchable apps. D-pad moves, OK opens, hold OK hides the app.
 *
 * EXTRA_PICK   returns the chosen package (used when binding a D-pad key to an app; shows hidden apps too).
 * EXTRA_MANAGE shows every app, hidden ones dimmed; OK hides or unhides the selected app.
 */
class AppGridActivity : BaseActivity() {

    companion object {
        const val EXTRA_PICK = "pick"
        const val EXTRA_MANAGE = "manage"
        const val EXTRA_PACKAGE = "package"
    }

    private class Entry(
        val label: String,
        val pkg: String?,
        val component: ComponentName?,
        val icon: Drawable?,
        var hidden: Boolean = false
    )

    private val items = ArrayList<Entry>()
    private lateinit var prefs: Prefs
    private lateinit var grid: GridView
    private lateinit var header: TextView
    private var pickMode = false
    private var manageMode = false
    private var columns = 3
    private var iconSize = 0

    private val gridAdapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val ctx = this@AppGridActivity
            val cell: LinearLayout
            if (convertView is LinearLayout) {
                cell = convertView
            } else {
                cell = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(2), dp(8), dp(2), dp(6))
                }
                val icon = ImageView(ctx).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    layoutParams = LinearLayout.LayoutParams(iconSize, iconSize)
                }
                val name = TextView(ctx).apply {
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    setTextColor(Ui.TEXT)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, if (columns == 2) 15f else 12f)
                    setPadding(0, dp(4), 0, 0)
                }
                cell.addView(icon)
                cell.addView(name)
            }
            val e = items[position]
            val dimmed = manageMode && e.hidden
            val icon = cell.getChildAt(0) as ImageView
            icon.setImageDrawable(e.icon)
            icon.alpha = if (dimmed) 0.3f else 1f
            val name = cell.getChildAt(1) as TextView
            name.text = if (dimmed) e.label + " (hidden)" else e.label
            name.setTextColor(if (dimmed) Ui.SUB else Ui.TEXT)
            return cell
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Menu slides up from the bottom when opened.
        overridePendingTransition(R.anim.slide_up, R.anim.stay)
        prefs = Prefs(this)
        pickMode = intent.getBooleanExtra(EXTRA_PICK, false)
        manageMode = intent.getBooleanExtra(EXTRA_MANAGE, false)
        columns = prefs.gridColumns
        iconSize = (resources.displayMetrics.widthPixels / columns * 0.6f).toInt()

        grid = GridView(this).apply {
            numColumns = columns
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(6)
            horizontalSpacing = dp(4)
            setPadding(dp(4), dp(6), dp(4), dp(6))
            clipToPadding = false
            selector = Ui.selector(this@AppGridActivity)
            setDrawSelectorOnTop(false)
            adapter = gridAdapter
            setOnItemClickListener { _, _, position, _ -> onEntryChosen(items[position]) }
            setOnItemLongClickListener { _, _, position, _ -> onEntryLongPressed(items[position]) }
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) =
                    updateHeader()

                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
        }

        val title = when {
            pickMode -> "Pick an app"
            manageMode -> "Hide / unhide apps"
            else -> "All apps"
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        // Top bar: the name of the selected app (or the screen title in pick / hide modes).
        header = Ui.header(this, title)
        root.addView(header)
        root.addView(grid, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        // Reload every time so changes made in the hide/unhide screen show up here.
        loadApps()
    }

    private fun loadApps() {
        val hiddenSet = prefs.hiddenApps
        Thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    Entry(
                        it.loadLabel(pm).toString(),
                        it.activityInfo.packageName,
                        ComponentName(it.activityInfo.packageName, it.activityInfo.name),
                        it.loadIcon(pm),
                        it.activityInfo.packageName in hiddenSet
                    )
                }
                .filter { manageMode || pickMode || !it.hidden }
                .sortedBy { it.label.lowercase() }

            runOnUiThread {
                val keep = grid.selectedItemPosition
                items.clear()
                if (!pickMode && !manageMode) {
                    items.add(Entry("Launcher", null, null, getDrawable(android.R.drawable.ic_menu_preferences)))
                }
                items.addAll(apps)
                gridAdapter.notifyDataSetChanged()
                grid.setSelection(if (keep in 0 until items.size) keep else 0)
                grid.requestFocus()
                updateHeader()
            }
        }.start()
    }

    private fun updateHeader() {
        if (pickMode || manageMode) return
        val i = grid.selectedItemPosition
        header.text = if (i in 0 until items.size) items[i].label else ""
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.stay, R.anim.slide_down)
    }

    private fun onEntryChosen(e: Entry) {
        when {
            e.pkg == null -> startActivity(Intent(this, LauncherSettingsActivity::class.java))
            manageMode -> setHidden(e, !e.hidden)
            pickMode -> {
                setResult(RESULT_OK, Intent().putExtra(EXTRA_PACKAGE, e.pkg))
                finish()
            }
            else -> {
                val launch = Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(e.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                try {
                    startActivity(launch)
                } catch (ex: Exception) {
                    Actions.toast(this, "Can't open that")
                }
            }
        }
    }

    /** Hold OK on an app in the normal menu to hide it. */
    private fun onEntryLongPressed(e: Entry): Boolean {
        if (e.pkg == null || pickMode || manageMode) return false
        AlertDialog.Builder(this)
            .setTitle("Hide " + e.label + "?")
            .setMessage("Unhide it later in Launcher settings.")
            .setPositiveButton("Hide") { _, _ ->
                setHidden(e, true)
                items.remove(e)
                gridAdapter.notifyDataSetChanged()
            }
            .setNegativeButton("Cancel", null)
            .show()
        return true
    }

    private fun setHidden(e: Entry, hide: Boolean) {
        val pkg = e.pkg ?: return
        val set = prefs.hiddenApps.toMutableSet()
        if (hide) set.add(pkg) else set.remove(pkg)
        prefs.hiddenApps = set
        e.hidden = hide
        gridAdapter.notifyDataSetChanged()
    }
}
