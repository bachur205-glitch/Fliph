package com.flipdeck.launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Big-icon grid of every launchable app. D-pad moves, OK opens.
 * With EXTRA_PICK it instead returns the chosen package (used when binding a D-pad key to an app).
 */
class AppGridActivity : Activity() {

    companion object {
        const val EXTRA_PICK = "pick"
        const val EXTRA_PACKAGE = "package"
    }

    private class Entry(
        val label: String,
        val pkg: String?,
        val component: ComponentName?,
        val icon: Drawable?
    )

    private val items = ArrayList<Entry>()
    private lateinit var grid: GridView
    private var pickMode = false
    private var columns = 3
    private var iconSize = 0

    private val gridAdapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val ctx = this@AppGridActivity
            val cell: LinearLayout
            if (convertView is LinearLayout) {
                cell = convertView
            } else {
                cell = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(2), dp(8), dp(2), dp(6))
                }
                val icon = ImageView(ctx).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    layoutParams = LinearLayout.LayoutParams(iconSize, iconSize)
                }
                val name = TextView(ctx).apply {
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    setTextColor(Ui.TEXT)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, if (columns == 2) 15f else 12f)
                    setPadding(0, dp(4), 0, 0)
                }
                cell.addView(icon)
                cell.addView(name)
            }
            val e = items[position]
            (cell.getChildAt(0) as ImageView).setImageDrawable(e.icon)
            (cell.getChildAt(1) as TextView).text = e.label
            return cell
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pickMode = intent.getBooleanExtra(EXTRA_PICK, false)
        columns = Prefs(this).gridColumns
        iconSize = (resources.displayMetrics.widthPixels / columns * 0.6f).toInt()

        grid = GridView(this).apply {
            numColumns = columns
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(6)
            horizontalSpacing = dp(4)
            setPadding(dp(4), dp(6), dp(4), dp(6))
            clipToPadding = false
            selector = Ui.selector(this@AppGridActivity)
            setDrawSelectorOnTop(false)
            adapter = gridAdapter
            setOnItemClickListener { _, _, position, _ -> onEntryChosen(items[position]) }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        root.addView(Ui.header(this, if (pickMode) "Pick an app" else "All apps"))
        root.addView(grid, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)

        loadApps()
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    Entry(
                        it.loadLabel(pm).toString(),
                        it.activityInfo.packageName,
                        ComponentName(it.activityInfo.packageName, it.activityInfo.name),
                        it.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase() }

            runOnUiThread {
                items.clear()
                if (!pickMode) {
                    items.add(Entry("Launcher", null, null, getDrawable(android.R.drawable.ic_menu_preferences)))
                }
                items.addAll(apps)
                gridAdapter.notifyDataSetChanged()
                grid.setSelection(0)
                grid.requestFocus()
            }
        }.start()
    }

    private fun onEntryChosen(e: Entry) {
        when {
            e.pkg == null -> startActivity(Intent(this, LauncherSettingsActivity::class.java))
            pickMode -> {
                setResult(RESULT_OK, Intent().putExtra(EXTRA_PACKAGE, e.pkg))
                finish()
            }
            else -> {
                val launch = Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(e.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                try {
                    startActivity(launch)
                } catch (ex: Exception) {
                    Actions.toast(this, "Can't open that")
                }
            }
        }
    }
}
